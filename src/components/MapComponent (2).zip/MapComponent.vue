<template>
  <div id="map-container">
    <div id="map" style="height: 100vh;"></div>
    <div id="overlay-container" v-show="showOverlay">
      <button v-if="state === 1" @click="resetMap" class="map-button" :style="buttonStyle">取消选择</button>
      <button v-if="state === 1" @click="nextStep" class="map-button" :style="nextButtonStyle">下一步</button>
      <button v-if="state === 2" @click="previousStep" class="map-button" :style="previousButtonStyle">上一步</button>
      <button v-if="state === 2" @click="confirmSelection" class="map-button" :style="confirmButtonStyle">确定</button>
      <div id="chart-container" :style="{ 'pointer-events': isChartInteractive ? 'auto' : 'none' }">
        <div v-for="image in overlayImages" :key="image.id" class="chart-box" :style="imageStyle(image)">
          <svg :id="'svg' + image.id"></svg>
        </div>
      </div>
      <button v-if="isChartInteractive2" @click="saveChanges" class="map-button" :style="saveButtonStyle">保存修改</button>
    </div>
  </div>
</template>

<script>
import L from 'leaflet';
import Papa from 'papaparse';
import * as d3 from 'd3';

export default {
  name: 'MapComponent',
  data() {
    return {
      map: null,
      pointIcon: L.icon({
        iconUrl: require('@/assets/point.png'), // 蓝色
        iconSize: [40, 40],
      }),
      point2Icon: L.icon({
        iconUrl: require('@/assets/point2.png'), // 紫色-用于选中点
        iconSize: [50, 50],
      }),
      point3Icon: L.icon({
        iconUrl: require('@/assets/point3.png'), // 绿色打钩-用于参考点
        iconSize: [50, 50],
      }),
      selectedMarker: null,
      tempArray: [],
      showOverlay: false,
      markersInMap:[],
      nearbyStationIds: [], // 存储10公里范围内标记的ID
      airQualityData: [], // 存储查找到的空气质量数据
      state: 1,
      isChartInteractive: false,
      previousButtonStyle: {
        position: 'absolute',
          left: `50%`,
          top: `77%`,
          transform: 'translate(-50%, -50%)'
      },
      confirmButtonStyle: {
        position: 'absolute',
          left: `50%`,
          top: `84%`,
          transform: 'translate(-50%, -50%)'
      },
      buttonStyle: {},
      nextButtonStyle: {},
      overlayImages: [],
      missingDataIntervals:[],
      missingY:[],
      containerData: {},
      filledCircles:[],
      saveButtonStyle: {
        position: 'absolute',
        left: '57%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
      },
      transformedCircles: [],
      isChartInteractive2: false,
    };
  },
  mounted() {
    const urlParams = new URLSearchParams(window.location.search);
    const lat = urlParams.get('lat');
    const lng = urlParams.get('lng');
    const zoom = urlParams.get('zoom') || 11;

    this.markersInMap = []

    this.map = L.map('map').setView([lat || 40, lng || 116.18], zoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors'
    }).addTo(this.map);

    this.loadStations();
  },

  methods: {
    loadStations() {
      fetch('/Data/station.csv')
      .then(response => response.text())
      .then(csv => {
        Papa.parse(csv, {
          header: true,
          complete: results => {
            results.data.forEach(station => {
              if (station.latitude && station.longitude) {
                  const marker = L.marker([station.latitude, station.longitude], {
                    icon: this.pointIcon, stationId: station.station_id,
                    latitude: station.latitude, longitude: station.longitude})
                    .addTo(this.map)
                    // .bindPopup(`<b>${station.name_chinese}</b><br>Station ID: ${station.station_id}`);
                  this.markersInMap.push(marker)
                  // marker.stationId = station.station_id;
                  // console.log("station_id", station.station_id); 
              }
            });
          }
        });
      });
      // 异步加载空气质量数据
      this.loadAllAirQualityData().then(() => {
        this.markersInMap.forEach(marker => {
          marker.on('click', () => {
            this.onMarkerClick(marker);
          });
        });
      });
    },

    onMarkerClick(marker) {
      if (this.selectedMarker && this.selectedMarker !== marker) {
        //如果之前有选中的marker，恢复为小蓝标
        this.selectedMarker.setIcon(this.pointIcon);
      }

      //更新当前选中的大紫标
      this.selectedMarker = marker;
      marker.setIcon(this.point2Icon);

      this.map.setView(marker.getLatLng(), 12);

      this.selectedMarker = marker;
      this.selectedMarker.stationID = marker.options.stationId;
      // this.map.zoomControl.disable();
      // this.map.scrollWheelZoom.disable();
      // this.map.dragging.disable();

      this.showOverlay = false;

      setTimeout(() => {
        this.buttonStyle = {
          position: 'absolute',
          left: `50%`,
          top: `77%`,
          transform: 'translate(-50%, -50%)'
        };
        this.nextButtonStyle = {
          position: 'absolute',
          left: '50%',
          top: '84%',
          transform: 'translate(-50%, -50%)',
        };
        this.showOverlay = true;
      }, 150);

      //计算范围 (10 -> 20 -> 40km)
      this.calculateNearbyStations(marker, 0.09); // 经纬度差0.09对应约10公里

      // 如果找到的点少于2个，扩大到20km
      if (this.nearbyStationIds.length < 2) {
        this.calculateNearbyStations(marker, 0.18); // 扩大一倍

        // 40km
        if (this.nearbyStationIds.length < 2) {
          this.calculateNearbyStations(marker, 0.36); // 再次扩大
        }
      }

      const recentData = this.findDataForStation(marker.options.stationId);
      if (recentData.length > 0) {
        this.createSvg(recentData);
      }

      // 在屏幕中间位置创建SVG画布
      this.createSvg(recentData);
    },

    findDataForStation(stationId) {
      // 筛选ID对应的空气质量数据（线性查找太久，本身有序故二分）
      const stationIdIndex = this.binarySearch(this.airQualityData, (data) => {
        return stationId.localeCompare(data.station_id);
      });

      if (stationIdIndex === -1) {
        // 没有找到
        return [];
      }

      // 找到某行id符合，向前找到id对应第一行
      let firstMatchIndex = stationIdIndex;
      while (firstMatchIndex > 0 && this.airQualityData[firstMatchIndex - 1].station_id === stationId) {
        firstMatchIndex--;
      }

      // 从第一条开始向后存所有本id的数据
      let matchedData = [];
      let currentIndex = firstMatchIndex;
      while (currentIndex < this.airQualityData.length && this.airQualityData[currentIndex].station_id === stationId) {
        matchedData.push(this.airQualityData[currentIndex]);
        currentIndex++;
      }

      // 取时间最近的24条记录
      return matchedData.slice(0, 24);
    },

    binarySearch(array, compareFn) {
      let low = 0, high = array.length - 1;

      while (low <= high) {
        const mid = Math.floor((low + high) / 2);
        const comparison = compareFn(array[mid]);
        
        if (comparison === 0) return mid;
        else if (comparison < 0) high = mid - 1;
        else low = mid + 1;
      }

      return -1; // 没有找到
    },

    createSvg(data) {
      // 计算SVG位置和尺寸
      const screenWidth = window.innerWidth;
      const screenHeight = window.innerHeight;
      const svgWidth = screenWidth * 0.4;
      const svgHeight = 150

      // 创建SVG元素
      const svg = d3.select('#overlay-container').append('svg').classed('data-svg1', true)
        .attr('width', svgWidth)
        .attr('height', svgHeight)
        .attr('style', `position: absolute; left: ${screenWidth / 2 - svgWidth / 2}px; top: ${screenHeight * 0.2}px;`)
        .style('background-color', 'white')
        .style('border', '2px solid #007bff')
        .style('border-radius', '10px')
        .style('opacity','0.9');
      
      const margin = { top: 10, right: 30, bottom: 30, left: 40 };
      const innerWidth = svgWidth - margin.left - margin.right;
      const innerHeight = svgHeight - margin.top - margin.bottom;

      // 创建内部SVG组
      const g = svg.append("g")
        .attr("transform", `translate(${margin.left}, ${margin.top})`);

      // 创建比例尺
      const xScale = d3.scaleTime()
        .domain(d3.extent(data, d => new Date(d.time)))
        .range([0, innerWidth]);

      const yScale = d3.scaleLinear()
        .domain([0, d3.max(data, d => +d.PM25_Concentration) + 30])
        .range([innerHeight, 0]);

      // 添加坐标轴
      g.append("g")
        .attr("transform", `translate(0, ${innerHeight})`)
        .call(d3.axisBottom(xScale));

      g.append("g")
        .call(d3.axisLeft(yScale));

      // 绘制曲线
      this.missingDataIntervals = [];
      this.missingY = [];
      const segments = this.splitDataIntoSegments(data);
      //console.log("missingDataIntervals: " + JSON.stringify(this.missingDataIntervals, null, 2));
      segments.forEach(segment => {
        g.append("path")
          .datum(segment)
          .attr("fill", "none")
          .attr("stroke", "steelblue")
          .attr("stroke-width", 1.5)
          .attr("d", d3.line()
            .x(d => xScale(new Date(d.time)))
            .y(d => yScale(+d.PM25_Concentration))
          );
      });

      // 绘制缺失数据的红色虚线矩形框
      this.missingDataIntervals.forEach(interval => {
        const startX = xScale(new Date(interval.start));
        const endX = xScale(new Date(interval.end));
        const rectWidth = endX - startX;
        
        // 调整稍窄
        const adjustedWidth = rectWidth > 6 ? rectWidth - 6 : rectWidth;
        const adjustedStartX = startX + (rectWidth - adjustedWidth) / 2;

        g.append("rect")
          .attr("x", adjustedStartX)
          .attr("y", 0)
          .attr("width", adjustedWidth)
          .attr("height", innerHeight)
          .style("stroke", "red")
          .style("fill", "none")
          .style("stroke-dasharray", ("3, 3"));
      });
    },

    calculateNearbyStations(marker, radius) {
      const latLng = marker.getLatLng();
      const latRange = [latLng.lat - radius, latLng.lat + radius];
      const lngRange = [latLng.lng - radius, latLng.lng + radius];

      this.nearbyStationIds = [];

      this.map.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          const layerLatLng = layer.getLatLng();
          if (layerLatLng.lat >= latRange[0] && layerLatLng.lat <= latRange[1] &&
              layerLatLng.lng >= lngRange[0] && layerLatLng.lng <= lngRange[1]) {
            const stationId = layer.options.stationId;
            this.nearbyStationIds.push(stationId);
          }
        }
      });
    },

    splitDataIntoSegments(data) {
      let segments = [];
      let currentSegment = [];
      let lastValidData = null; // 用于记录上一个有效数据点

      data.forEach(d => {
        if (this.isValidPM25(d.PM25_Concentration)) {
          if (currentSegment.length === 0 && lastValidData) {
            // 如果当前段是新的，且存在上一个有效数据点，则记录缺失数据的起始和结束时间
            this.missingDataIntervals.push({
              start: lastValidData.time,
              end: d.time
            });
            this.missingY.push({
              startY: lastValidData.PM25_Concentration,
              endY: d.PM25_Concentration
            });
          }
          currentSegment.push(d);
          lastValidData = d; // 更新最后一个有效数据点
        } else if (currentSegment.length > 0) {
          segments.push(currentSegment);
          currentSegment = [];
        }
      });

      if (currentSegment.length > 0) {
        segments.push(currentSegment);
      }

      return segments;
    },

    isValidPM25(value) {
      return value != null && !isNaN(value) && value !== 0;
    },

    loadAllAirQualityData() {
      return new Promise((resolve) => {
        Papa.parse('/Data/airquality.csv', {
          download: true,
          header: true,
          complete: (results) => {
            this.airQualityData = results.data;
            resolve();
          }
        });
      });
    },

    resetMap() {
      d3.select('#overlay-container .data-svg1').remove();
      if (this.selectedMarker) {
        const latLng = this.selectedMarker.getLatLng();
        this.map.setView(latLng, 11); // 设置地图视图为当前标记的位置，缩放级别为11

        // 重置marker图标为原始图标
        this.selectedMarker.setIcon(this.pointIcon);
        this.selectedMarker = null;
        this.showOverlay = false;
      }
    },

    nextStep() {
      d3.select('#overlay-container .data-svg1').remove();
      this.state = 2;

      // 移除SVG元素
      const svgElement = document.querySelector('#overlay-container > svg');
      if (svgElement) {
        svgElement.remove();
      }

      //改变参考点的图标
      this.markersInMap.forEach(marker => {
        if (this.nearbyStationIds.includes(marker.options.stationId) && marker !== this.selectedMarker) {
          marker.setIcon(this.point3Icon);
        }
      });

      // 更新点击逻辑
      this.markersInMap.forEach(marker => {
        marker.off('click').on('click', () => {
          this.toggleMarker(marker);
        });
      });
    },

    toggleMarker(marker) {
      const stationId = marker.options.stationId;
      if (marker !== this.selectedMarker) {
        if (this.nearbyStationIds.includes(stationId)) {
          this.nearbyStationIds = this.nearbyStationIds.filter(id => id !== stationId);
          marker.setIcon(this.pointIcon);
        } else {
          this.nearbyStationIds.push(stationId);
          marker.setIcon(this.point3Icon);
        }
      }
    },

    //上一步按钮
    previousStep() {
      this.state = 1;

      this.map.setView(this.selectedMarker.getLatLng(), 12);
      //改回参考点的图标
      this.markersInMap.forEach(marker => {
        if (this.nearbyStationIds.includes(marker.options.stationId) && marker !== this.selectedMarker) {
          marker.setIcon(this.pointIcon);
        }
      });

      // 恢复状态1的点击逻辑
      this.markersInMap.forEach(marker => {
        marker.off('click').on('click', () => {
          this.onMarkerClick(marker);
        });
      });
    },

    confirmSelection() {
      this.state = 3;
      this.isChartInteractive = true; // 开放chart-container的操作
      this.carryOverlayImages();
    },

    carryOverlayImages() {
      const screenHeight = window.innerHeight; // 容器高度
      const screenWidth = window.innerWidth / 2; // 容器宽度
      const imageHeight = screenHeight * 0.2; // 容器宽度
      const imageWidth = screenWidth * 0.95; // 矩形宽度
      const margin = screenHeight * 0.005; // 空隙宽度
      let topOffset = margin;

      const sortedStationIds = this.nearbyStationIds.sort((a, b) => {
        const latA = this.getMarkerLatLngById(a).lat;
        const latB = this.getMarkerLatLngById(b).lat;
        return latB - latA; // 按纬度降序排列
      });

      this.overlayImages = sortedStationIds.map((id, index) => {
        const imageTop = topOffset + index * (imageHeight + margin); // 每个矩形的上边缘
        return {
          id,
          top: imageTop,
          left: screenWidth * 0.005, // 矩形左边缘，虽然左右空隙一共0.05，但根据运行调整得宽度如此左右空隙才能对称
          width: imageWidth,
          height: imageHeight
        };
      });

      console.log("selectedMarker.stationID: " + this.selectedMarker.stationID);
      console.log("this.selectedMarker: " + this.selectedMarker);
      this.overlayImages.forEach(image => {
        // 等待DOM更新后绘制图表
        this.$nextTick(() => {
          const { xScale, yScale, innerHeight } = this.drawSvg('svg' + image.id);

          console.log("image.id: " + image.id);
          // 对选中点
          if (this.selectedMarker && 'svg' + image.id === 'svg' + this.selectedMarker.stationID) {
            console.log("it's here!");
            this.drawSelectedSvg('svg' + image.id, xScale, yScale, innerHeight);
          }
        });
      });
    },

    drawSvg(svgId) {
      const svgElement = document.querySelector('#overlay-container > svg');
      if (svgElement) {
        svgElement.remove();
      }

      const data = this.findDataForStation(svgId.replace('svg', ''));
      if (data.length === 0) {
        return; // 如果没有数据，就不进行绘制
      }

      // 分段
      const dataSegments = this.splitDataIntoSegments(data);

      const svg = d3.select('#' + svgId);
      const svgWidth = svg.node().clientWidth;
      const svgHeight = svg.node().clientHeight;

      const margin = { top: 20, right: 30, bottom: 20, left: 35 };
      const innerWidth = svgWidth - margin.left - margin.right;
      const innerHeight = svgHeight - margin.top - margin.bottom;

      const g = svg.append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);

      const xScale = d3.scaleTime()
        .domain(d3.extent(data, d => new Date(d.time)))
        .range([0, innerWidth]);

      const yScale = d3.scaleLinear()
        .domain([0, d3.max(data, d => +d.PM25_Concentration) + 30])
        .range([innerHeight, 0]);

      g.append('g')
        .attr('transform', `translate(0,${innerHeight})`)
        .call(d3.axisBottom(xScale));

      g.append('g')
        .call(d3.axisLeft(yScale));

      this.containerData[svgId] = [];
      
      // 为每个数据段绘制曲线
      dataSegments.forEach(segment => {
        g.append('path')
          .datum(segment)
          .attr('fill', 'none')
          .attr('stroke', 'steelblue')
          .attr('stroke-width', 1.5)
          .attr('d', d3.line()
            .x(d => xScale(new Date(d.time)))
            .y(d => yScale(+d.PM25_Concentration))
          );
        segment.forEach(d => {
          const point = {
            x: xScale(new Date(d.time)),
            y: yScale(+d.PM25_Concentration),
            data: d
          };
          this.containerData[svgId].push(point);
        });
      });

      // console.log(this.containerData[svgId]);

      // svg.on("mousemove", (event) => {
      //   console.log("Mousemove on SVG: " + svgId); // 调试信息
      //   const [mouseX, mouseY] = d3.pointer(event);
      //   this.checkMouseProximity(mouseX, mouseY, svgId);
      // });

      // 返回scale和尺寸给其他方法用
      return { xScale, yScale, innerHeight };
    },

    // checkMouseProximity(mouseX, mouseY, svgId) {
    //   const proximityRadius = 5; // 判定范围
    //   const svg = d3.select('#' + svgId);
    //   const g = svg.select('g');

    //   const svgRect = svg.node().getBoundingClientRect();
    //   const adjustedMouseX = mouseX - svgRect.left;
    //   const adjustedMouseY = mouseY - svgRect.top;

    //   let isNearAnyPoint = false;

    //   this.containerData[svgId].forEach(point => {
    //     const distance = Math.sqrt(Math.pow(point.x - adjustedMouseX, 2) + Math.pow(point.y - adjustedMouseY, 2));
    //     if (distance <= proximityRadius) {
    //       isNearAnyPoint = true;
    //       // 绘制绿色实心点
    //       g.append('circle')
    //         .attr('class', 'interactive-circle')
    //         .attr('cx', point.x)
    //         .attr('cy', point.y)
    //         .attr('r', 2)
    //         .style('fill', 'green');

    //       // 显示点对应的信息
    //     }
    //   });

    //   // 如果鼠标离开数据点则清除
    //   if (!isNearAnyPoint) {
    //     g.selectAll('circle.interactive-circle').remove();
    //   }
    // },

    drawSelectedSvg(svgId, xScale, yScale, innerHeight) {
      console.log("drawSelectedSvg running!");
      const data = this.findDataForStation(svgId.replace('svg', ''));
      if (data.length === 0) {
        return; // 如果没有数据则不画曲线图
      }

      const svg = d3.select('#' + svgId);
      const g = svg.select('g');
      const proximityRadius = 5; // 鼠标靠近判定半径
      let guideLineXCoords = [];
      this.filledCircles = [];
      
      let startX, startY, endX, endY = null;

      // 对缺失数据段
      this.missingDataIntervals.forEach((interval, index) => {
        //前后有效点的坐标
        startX = xScale(new Date(interval.start));
        startY = yScale(this.missingY[index].startY);
        endX = xScale(new Date(interval.end));
        endY = yScale(this.missingY[index].endY);

        // 缺失段开始点
        g.append('circle')
          .attr('cx', startX)
          .attr('cy', startY)
          .attr('r', 3)
          .style('fill', 'none')
          .style('stroke', 'red');

        // 结束点
        g.append('circle')
          .attr('cx', endX)
          .attr('cy', endY)
          .attr('r', 3)
          .style('fill', 'none')
          .style('stroke', 'red');

        // 缺失数据竖直引导线
        const startTime = new Date(interval.start);
        const endTime = new Date(interval.end);
        for (let time = new Date(startTime); time <= endTime; time.setHours(time.getHours() + 1)) {
          const guideLineX = xScale(time);
          guideLineXCoords.push(guideLineX);
          
          g.append('line')
            .attr('x1', xScale(time))
            .attr('y1', 0)
            .attr('x2', xScale(time))
            .attr('y2', innerHeight)
            .style('stroke', 'grey')
            .style('stroke-dasharray', ('2, 2'));
        }
      });

      guideLineXCoords = guideLineXCoords.filter((value, index, self) => self.indexOf(value) === index);// 去重
      guideLineXCoords.sort((a, b) => a - b); // 排序
      if (guideLineXCoords.length > 2) {
        guideLineXCoords.shift(); // 删最小值
        guideLineXCoords.pop(); // 删最大值
      }
      //console.log("Guide line X coordinates without min and max: ", guideLineXCoords);

      // 鼠标移动事件
      svg.on("mousemove", (event) => {
        const [mouseX, mouseY] = d3.pointer(event, g.node());

        // 开始和结束点
        let nearStart = Math.hypot(startX - mouseX, startY - mouseY) <= proximityRadius;
        let nearEnd = Math.hypot(endX - mouseX, endY - mouseY) <= proximityRadius;

        g.selectAll('.start-circle').remove();
        g.selectAll('.end-circle').remove();
        if (nearStart) {
          g.append('circle').classed('start-circle', true)
            .attr('cx', startX).attr('cy', startY).attr('r', 3).style('fill', 'red');
        }
        if (nearEnd) {
          g.append('circle').classed('end-circle', true)
            .attr('cx', endX).attr('cy', endY).attr('r', 3).style('fill', 'red');
        }

        // 清除之前的空心圆形和文本框
        g.selectAll('.hollow-circle, .text-box, .text-label').remove();

        // 检查鼠标是否靠近引导线
        const nearGuideLineIndex = guideLineXCoords.findIndex(guideLineX => Math.abs(mouseX - guideLineX) <= proximityRadius / 3);
        const nearGuideLineX = guideLineXCoords[nearGuideLineIndex];

        if (nearGuideLineIndex >= 0 && mouseY >= 0 && mouseY <= innerHeight) {
          // 在靠近的引导线上绘制一个空心圆形
          g.append('circle').classed('hollow-circle', true)
            .attr('cx', nearGuideLineX).attr('cy', mouseY).attr('r', 3)
            .style('fill', 'none').style('stroke', 'red');
          
          // 文本内容
          const textContent = "Y: " + yScale.invert(mouseY).toFixed(2);

          // 绘制文本框背景
          g.append('rect').classed('text-box', true)
            .attr('x', nearGuideLineX + 5)
            .attr('y', mouseY - 10)
            .attr('width', 60)
            .attr('height', 18)
            .style('fill', 'white')
            .style('stroke', '#007bff')
            .style('opacity', 0.8);

          // 绘制文本
          g.append('text').classed('text-label', true)
            .attr('x', nearGuideLineX + 7)
            .attr('y', mouseY)
            .text(textContent)
            .style('font-size', '12px')
            .style('font-family', 'Arial, sans-serif');
        }
      });

      // 鼠标点击事件
      svg.on("click", (event) => {
        const [mouseX, mouseY] = d3.pointer(event, g.node());

        // 首先清除所有之前的线段和实心圆形
        g.selectAll('.guide-line').remove();
        g.selectAll('.filled-circle').remove();

        // 检查鼠标是否靠近引导线
        const nearGuideLineIndex = guideLineXCoords.findIndex(guideLineX => Math.abs(mouseX - guideLineX) <= proximityRadius / 3);
        const nearGuideLineX = guideLineXCoords[nearGuideLineIndex];

        if (nearGuideLineIndex >= 0 && mouseY >= 0 && mouseY <= innerHeight) {
          // 更新 filledCircles 数组
          const existingIndex = this.filledCircles.findIndex(circle => Math.abs(circle.x - nearGuideLineX) < proximityRadius / 3);
          if (existingIndex >= 0) {
            this.filledCircles.splice(existingIndex, 1); // 移除已有坐标
          }
          this.filledCircles.push({x: nearGuideLineX, y: mouseY}); // 添加新坐标

          // 绘制实心圆形
          this.filledCircles.forEach(circle => {
            g.append('circle').classed('filled-circle', true)
              .attr('cx', circle.x).attr('cy', circle.y).attr('r', 3)
              .style('fill', 'red');
          });
        }

        //画线
        guideLineXCoords.sort((a, b) => a - b);

        let previousPoint = null; // 用于存储前一个点

        guideLineXCoords.forEach((guideLineX, index) => {
          // 查找filledCircles中横坐标等于guideLineX的点
          const currentPoint = this.filledCircles.find(circle => circle.x === guideLineX);

          if (currentPoint) {
            // 如果是最小的guideLineX，则与开始点相连
            if (index === 0) {
              g.append('line').classed('guide-line', true)
                .attr('x1', startX).attr('y1', startY)
                .attr('x2', currentPoint.x).attr('y2', currentPoint.y)
                .style('stroke', 'blue');
            }

            // 连接当前点与前一个点
            if (previousPoint) {
              g.append('line').classed('guide-line', true)
                .attr('x1', previousPoint.x).attr('y1', previousPoint.y)
                .attr('x2', currentPoint.x).attr('y2', currentPoint.y)
                .style('stroke', 'blue');
            }

            previousPoint = currentPoint; // 更新前一个点为当前点

            // 如果是最大的guideLineX，则与结束点相连
            if (index === guideLineXCoords.length - 1) {
              g.append('line').classed('guide-line', true)
                .attr('x1', currentPoint.x).attr('y1', currentPoint.y)
                .attr('x2', endX).attr('y2', endY)
                .style('stroke', 'blue');
            }
          }
        });
        this.transformedCircles = this.filledCircles.map(circle => ({
          x: xScale.invert(circle.x),
          y: yScale.invert(circle.y)
        }));
      });
      this.isChartInteractive2 = true;
    },

    saveChanges() {
      if (this.selectedMarker) {
        console.log('当前补充数据的监测站id: ', this.selectedMarker.stationID);
      } else {
        console.log('');
      }
      console.log('保存的坐标: ', this.transformedCircles);
    },

    getMarkerLatLngById(stationId) {
      const marker = this.markersInMap.find(m => m.options.stationId === stationId);
      return marker ? marker.getLatLng() : null;
    },

    imageStyle(image) {
      return {
        position: 'absolute',
        top: image.top + 'px',
        left: image.left + 'px',
        width: image.width + 'px',
        height: image.height + 'px',
        backgroundColor: 'white',
        margin: '5px',
        boxSizing: 'border-box',
        border: '2px solid #007bff',
        borderRadius: '10px',
      };
    },
  }
};
</script>

<style>
/* Leaflet CSS */
@import "~leaflet/dist/leaflet.css";

html, body {
  margin: 0;
  padding: 0;
  height: 100%;
}

#map-container {
  position: relative;
}

#overlay-container {
  pointer-events: none;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1000; /* 确保容器在地图层之上 */
  display: flex; /* 可根据需要调整布局 */
  justify-content: center;
  align-items: center;
}

#overlay-container > * {
  pointer-events: auto; /* 确保容器内部的元素可以交互 */
}

#chart-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 50%; /* 占据屏幕左半边 */
  height: 100vh; /* 与视窗高度相同 */
  overflow-y: auto; /* 允许垂直滚动 */
}

.map-button {
  pointer-events: auto;
  cursor: pointer; /*鼠标悬停为手形*/
  height: 45px;
  width: 100px;
  padding: 10px;
  border: none;
  background-color: white;
  color: #007bff;
  border: 2px solid #007bff;
  font-size: 17px;
  font-family: "微软雅黑", sans-serif;
  border-radius: 5px;
  opacity: 0.8; /*不透明度*/
}

.chart-box {
  position: relative;
  overflow: hidden;
}

.chart-box svg {
  width: 90%;
  height: 90%;
  position: absolute;
  top: 5%;
  left: 5%;
}

</style>
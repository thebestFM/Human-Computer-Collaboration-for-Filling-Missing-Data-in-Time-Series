<template>
  <div id="map-container">
    <div id="map" style="height: 100vh;"></div>
    <div id="overlay-container" v-show="showOverlay">
    <button v-if="selectedMarker" @click="resetMap" class="map-button" :style="buttonStyle">取消选择</button>
    </div>
  </div>
</template>

<script>
import L from 'leaflet';
import Papa from 'papaparse';
import { openDB } from 'idb';

export default {
  name: 'MapComponent',
  data() {
    return {
      map: null,
      pointIcon: L.icon({
        iconUrl: require('@/assets/point.png'),//蓝色
        iconSize: [40, 40],
      }),
      point2Icon: L.icon({
        iconUrl: require('@/assets/point2.png'),//紫色-用于选中点
        iconSize: [50, 50],
      }),
      selectedMarker: null,
      tempArray: [],
      showOverlay: false,
      nearbyStationIds: [],//存储10公里范围内标点ID
      loadedStationIds: [], //存储已经加载过数据的标点ID
      airQualityData: [],//存储查找到的空气质量数据
    };
  },
  async mounted() {
    // 初始化数据库
    this.db = await openDB('AirQualityApp', 1, {
      upgrade(db) {
        db.createObjectStore('data', { keyPath: 'key' });
      },
    });

    // 加载已存储的数据
    this.loadStoredData();

    //原mount逻辑
    const urlParams = new URLSearchParams(window.location.search);
    const lat = urlParams.get('lat');
    const lng = urlParams.get('lng');
    const zoom = urlParams.get('zoom') || 11;

    this.map = L.map('map').setView([lat || 40, lng || 116.18], zoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors'
    }).addTo(this.map);

    this.loadStations();
  },
  methods: {
    async loadStoredData() {
      this.tempArray = (await this.db.get('data', 'tempArray')) || [];
      this.nearbyStationIds = (await this.db.get('data', 'nearbyStationIds')) || [];
      const loadedStationIdsData = (await this.db.get('data', 'loadedStationIds')) || [];
      this.loadedStationIds = Array.isArray(loadedStationIdsData) ? loadedStationIdsData : [];
      this.airQualityData = (await this.db.get('data', 'airQualityData')) || [];
    },

    loadStations() {
      fetch('/Data/station.csv')
        .then(response => response.text())
        .then(csv => {
          Papa.parse(csv, {
            header: true,
            complete: results => {
              results.data.forEach(station => {
                if (station.latitude && station.longitude) {
                    const marker = L.marker([station.latitude, station.longitude], {
                      icon: this.pointIcon, stationId: station.station_id
                      ,latitude: station.latitude, longitude: station.longitude})
                      .addTo(this.map)
                      .bindPopup(`<b>${station.name_chinese}</b><br>Station ID: ${station.station_id}`);
                    
                    //点击事件监听器
                    marker.on('click', () => {
                      this.onMarkerClick(marker);
                    });
                }
              });
            }
          });
        });
    },

    async updateAndStoreData(key, data) {
      this[key] = data;
      try {
        await this.db.put('data', { key: key, data: data });
      } catch (error) {
        console.error("Error storing data in IndexedDB: ", error);
        // 可能需要对数据进行进一步处理或序列化
      }
    },


    onMarkerClick(marker) {
      if (this.selectedMarker && this.selectedMarker !== marker) {
        //如果之前有选中的marker，恢复为小蓝标
        this.selectedMarker.setIcon(this.pointIcon);
      }

      //更新当前选中的大紫标
      this.selectedMarker = marker;
      marker.setIcon(this.point2Icon);

      //console.log(marker.options.stationId);

      this.selectedMarker = marker;
      this.map.setView(marker.getLatLng(), 12);
      this.map.zoomControl.disable();
      this.map.scrollWheelZoom.disable();
      this.map.dragging.disable();

      this.buttonStyle = {
        position: 'absolute',
        left: `50%`,
        top: `57%`,
        transform: 'translate(-50%, -50%)'
      };
      this.showOverlay = true;

      //计算10km范围
      const radius = 0.09; // 大约10公里的经纬度范围
      const latLng = marker.getLatLng();
      const latRange = [latLng.lat - radius, latLng.lat + radius];
      const lngRange = [latLng.lng - radius, latLng.lng + radius];

      this.nearbyStationIds = []; // 清空附近标记ID数组

      this.map.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          const layerLatLng = layer.getLatLng();
          if (layerLatLng.lat >= latRange[0] && layerLatLng.lat <= latRange[1] &&
              layerLatLng.lng >= lngRange[0] && layerLatLng.lng <= lngRange[1]) {
            // 处理并添加ID
            const stationId = layer.options.stationId.replace(/^0+/, ''); // 删除ID前面的0
            this.nearbyStationIds.push(stationId);
          }
        }
      });
      
      //加载范围点数据
      this.loadAirQualityData(this.nearbyStationIds);
    },

    loadAirQualityData(stationIds) {
      Papa.parse('/Data/airquality.csv', {
        download: true,
        header: true,
        step: (row) => {
          const data = row.data;
          const normalizedId = data.station_id.replace(/^0+/, ''); // 删除ID前面的0

          if (stationIds.includes(normalizedId) && !this.loadedStationIds.includes(normalizedId)) {
            this.airQualityData.push(data); // 将新数据添加到数组中
          }
        },
        complete: async () => {
          // 存储新查询过的ID
          const newLoadedIds = stationIds.filter(id => !this.loadedStationIds.includes(id));
          this.updateAndStoreData('loadedStationIds', [...this.loadedStationIds, ...newLoadedIds]);
          
          // 存储空气质量数据
          this.updateAndStoreData('airQualityData', this.airQualityData);

          console.log("Loaded air quality data: ", this.airQualityData);
        }
      });
    },

    resetMap() {
      if (this.selectedMarker) {
        const latLng = this.selectedMarker.getLatLng();
        this.tempArray.push(latLng);
        window.location.href = `${window.location.pathname}?lat=${latLng.lat}&lng=${latLng.lng}&zoom=11`;
      
        // 重置marker图标
        this.selectedMarker.setIcon(this.pointIcon);
        this.selectedMarker = null;
      }
    },
  }
};
</script>

<style>
/* Leaflet CSS */
@import "~leaflet/dist/leaflet.css";

html, body {
  margin: 0;
  padding: 0;
  height: 100%;
}

#map-container {
  position: relative;
}

#overlay-container {
  pointer-events: none;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1000; /* 确保容器在地图层之上 */
  display: flex; /* 可根据需要调整布局 */
  justify-content: center;
  align-items: center;
}

#overlay-container > * {
  pointer-events: auto; /* 确保容器内部的元素可以交互 */
}

.map-button {
  pointer-events: auto;
  cursor: pointer; /*鼠标悬停为手形*/
  height: 45px;
  width: 100px;
  padding: 10px;
  border: none;
  background-color: white;
  color: #007bff;
  border: 2px solid #007bff;
  font-size: 17px;
  font-family: "微软雅黑", sans-serif;
  border-radius: 5px;
}

</style>